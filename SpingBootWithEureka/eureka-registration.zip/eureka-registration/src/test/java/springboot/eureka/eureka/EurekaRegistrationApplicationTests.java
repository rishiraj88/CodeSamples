package springboot.eureka.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
